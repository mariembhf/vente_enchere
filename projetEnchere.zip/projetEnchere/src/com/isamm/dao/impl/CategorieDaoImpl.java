package com.isamm.dao.impl;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.isamm.dao.*;
import com.isamm.dao.*;
import com.isamm.model.*;

public class CategorieDaoImpl {
	
	
	public final void insererCategorie(Categorie c) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("projetEnchere");
		ProduitDao.em  = emf.createEntityManager();
		
		System.out.println("entity manager cr��");
		
		
		CategorieDao.insererCategorie(c);
		assertNotNull(c);
	}


	public final void modifierCategorie(Categorie c) {
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("projetEnchere");
	ProduitDao.em  = emf.createEntityManager();
	
	System.out.println("entity manager cr��");
	
	
	CategorieDao.modifierCategorie(c);
	assertNotNull(c);
	}
	
	public final void supprimerCategorie(Categorie c) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("projetEnchere");
		ProduitDao.em  = emf.createEntityManager();
		
		System.out.println("entity manager cr��");
	
		
		CategorieDao.supprimerCategorie(c);
		assertNotNull(c);
		}

}
